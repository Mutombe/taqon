import { useState, useEffect, lazy, Suspense } from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Toaster } from 'sonner'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import ScrollToTop from './components/ScrollToTop'
import { PolicyModal, CookieModal, CookieBanner } from './components/Modals'

/* Lazy load pages for code-splitting */
const Home = lazy(() => import('./pages/Home'))
const About = lazy(() => import('./pages/About'))
const Services = lazy(() => import('./pages/Services'))
const Gallery = lazy(() => import('./pages/Gallery'))
const Careers = lazy(() => import('./pages/Careers'))
const Contact = lazy(() => import('./pages/Contact'))

/* Loading spinner */
function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-cream">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
        className="w-10 h-10 border-3 border-gold-200 border-t-gold-500 rounded-full"
      />
    </div>
  )
}

/* Page transition wrapper */
function PageTransition({ children }) {
  const location = useLocation()
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -12 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  )
}

/* Dynamic page title/meta */
const PAGE_META = {
  '/': { title: 'Brite Shine Cleaning Services — Spotless Perfection', desc: 'Premium residential & commercial cleaning. Trusted by 800+ happy clients.' },
  '/about': { title: 'About Us — Brite Shine Cleaning Services', desc: 'Learn about our story, values, and the passionate team behind every spotless space.' },
  '/services': { title: 'Our Services — Brite Shine Cleaning Services', desc: 'Residential, commercial, deep cleaning, and more. Explore our comprehensive cleaning solutions.' },
  '/gallery': { title: 'Gallery — Brite Shine Cleaning Services', desc: 'See our work speak for itself. Browse before & after transformations.' },
  '/careers': { title: 'Careers — Brite Shine Cleaning Services', desc: 'Join our growing team. Explore open positions and build a career with purpose.' },
  '/contact': { title: 'Contact Us — Brite Shine Cleaning Services', desc: 'Get a free quote. Reach out via phone, email, or our contact form.' },
}

function SEOHandler() {
  const location = useLocation()
  useEffect(() => {
    const meta = PAGE_META[location.pathname] || PAGE_META['/']
    document.title = meta.title
    const descTag = document.querySelector('meta[name="description"]')
    if (descTag) descTag.setAttribute('content', meta.desc)
  }, [location.pathname])
  return null
}

export default function App() {
  const [policyOpen, setPolicyOpen] = useState(false)
  const [cookieModalOpen, setCookieModalOpen] = useState(false)
  const [cookieAccepted, setCookieAccepted] = useState(() => {
    try { return localStorage.getItem('bs-cookies') === 'true' } catch { return false }
  })

  const handleAcceptCookies = () => {
    setCookieAccepted(true)
    try { localStorage.setItem('bs-cookies', 'true') } catch {}
  }

  return (
    <BrowserRouter>
      <ScrollToTop />
      <SEOHandler />
      <Toaster position="top-right" richColors />

      <div className="flex flex-col min-h-screen">
        <Navbar />

        <main className="flex-1">
          <Suspense fallback={<PageLoader />}>
            <Routes>
              <Route path="/" element={<PageTransition><Home /></PageTransition>} />
              <Route path="/about" element={<PageTransition><About /></PageTransition>} />
              <Route path="/services" element={<PageTransition><Services /></PageTransition>} />
              <Route path="/gallery" element={<PageTransition><Gallery /></PageTransition>} />
              <Route path="/careers" element={<PageTransition><Careers /></PageTransition>} />
              <Route path="/contact" element={<PageTransition><Contact /></PageTransition>} />
            </Routes>
          </Suspense>
        </main>

        <Footer
          onOpenPolicy={() => setPolicyOpen(true)}
          onOpenCookies={() => setCookieModalOpen(true)}
        />
      </div>

      {/* Modals */}
      <PolicyModal open={policyOpen} onClose={() => setPolicyOpen(false)} />
      <CookieModal open={cookieModalOpen} onClose={() => setCookieModalOpen(false)} />

      {/* Cookie Banner */}
      <AnimatePresence>
        {!cookieAccepted && (
          <CookieBanner
            onAccept={handleAcceptCookies}
            onOpenPolicy={() => setCookieModalOpen(true)}
          />
        )}
      </AnimatePresence>
    </BrowserRouter>
  )
}
