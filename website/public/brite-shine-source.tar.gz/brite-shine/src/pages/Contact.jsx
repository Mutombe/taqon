import { useState } from 'react'
import { motion } from 'framer-motion'
import { toast } from 'sonner'
import { MapPin, Phone, Mail, Clock, Send, MessageCircle, ArrowRight, CheckCircle2 } from 'lucide-react'
import { useInView } from '../hooks/useIntersectionObserver'

export default function Contact() {
  return (
    <>
      <ContactHero />
      <ContactContent />
      <MapSection />
    </>
  )
}

/* ============================================
   CONTACT HERO
   Vision: Elegant, centered hero with a warm
   gradient background. Minimal and focused.
============================================ */
function ContactHero() {
  return (
    <section className="relative bg-hero-pattern pt-32 pb-16 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-32 right-20 w-72 h-72 bg-gold-200/20 rounded-full blur-[80px]" />
        <div className="absolute bottom-0 left-10 w-60 h-60 bg-gold-300/10 rounded-full blur-[60px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-3xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-gold mb-6">
            <MessageCircle className="w-4 h-4 text-gold-500" />
            <span className="text-sm font-heading font-medium text-gold-700">Get In Touch</span>
          </div>
          <h1 className="font-display text-5xl sm:text-6xl font-bold leading-tight mb-6">
            <span className="text-charcoal">Let's Make Your</span>
            <br />
            <span className="text-gradient-gold">Space Shine</span>
          </h1>
          <p className="text-charcoal/60 text-lg max-w-xl mx-auto">
            Ready for a sparkling clean? Get in touch for a free, no-obligation quote. We'd love to hear from you.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

/* ============================================
   CONTACT CONTENT
   Vision: Two-column layout. Left side has the
   contact form with elegant inputs. Right side
   has contact info cards stacked vertically with
   warm gold accents.
============================================ */
function ContactContent() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', service: '', message: '' })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    setSubmitted(true)
    toast.success('Message sent! We\'ll get back to you within 2 hours.', {
      style: { background: '#1C1C1E', color: '#fff', border: '1px solid rgba(212,184,106,0.2)' }
    })
  }

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const contactInfo = [
    { icon: Phone, label: 'Call Us', value: '+263 77 123 4567', href: 'tel:+263771234567', sub: 'Mon-Sat, 7AM-6PM' },
    { icon: Mail, label: 'Email Us', value: 'info@briteshine.co.zw', href: 'mailto:info@briteshine.co.zw', sub: 'We reply within 2 hours' },
    { icon: MapPin, label: 'Visit Us', value: '123 Shine Avenue, Business District', href: '#map', sub: 'Harare, Zimbabwe' },
    { icon: Clock, label: 'Working Hours', value: 'Mon – Sat: 7:00 AM – 6:00 PM', href: null, sub: 'Sundays by appointment' },
  ]

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-5 gap-16">
          {/* Form - Takes 3 columns */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-3"
          >
            <h2 className="font-display text-3xl font-bold text-charcoal mb-2">Request a Free Quote</h2>
            <p className="text-charcoal/50 mb-8">Fill out the form and we'll get back to you promptly.</p>

            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-gold-50 border border-gold-200 rounded-2xl p-12 text-center"
              >
                <CheckCircle2 className="w-16 h-16 text-gold-500 mx-auto mb-4" />
                <h3 className="font-display text-2xl font-bold text-charcoal mb-2">Thank You!</h3>
                <p className="text-charcoal/60">Your message has been sent successfully. Our team will reach out within 2 hours during business hours.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-heading font-medium text-charcoal mb-2">Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Your full name"
                      className="w-full px-4 py-3.5 rounded-xl border border-gold-200/60 bg-cream/50 text-charcoal placeholder:text-charcoal/30 focus:outline-none focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 transition-all font-body"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-heading font-medium text-charcoal mb-2">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="you@email.com"
                      className="w-full px-4 py-3.5 rounded-xl border border-gold-200/60 bg-cream/50 text-charcoal placeholder:text-charcoal/30 focus:outline-none focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 transition-all font-body"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-heading font-medium text-charcoal mb-2">Phone Number</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+263 77 000 0000"
                      className="w-full px-4 py-3.5 rounded-xl border border-gold-200/60 bg-cream/50 text-charcoal placeholder:text-charcoal/30 focus:outline-none focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 transition-all font-body"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-heading font-medium text-charcoal mb-2">Service Needed</label>
                    <select
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      className="w-full px-4 py-3.5 rounded-xl border border-gold-200/60 bg-cream/50 text-charcoal focus:outline-none focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 transition-all font-body appearance-none"
                    >
                      <option value="">Select a service</option>
                      <option value="residential">Residential Cleaning</option>
                      <option value="commercial">Commercial Cleaning</option>
                      <option value="deep">Deep Cleaning</option>
                      <option value="movein">Move-In/Out Cleaning</option>
                      <option value="carpet">Carpet & Upholstery</option>
                      <option value="sanitization">Sanitization</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-heading font-medium text-charcoal mb-2">Message *</label>
                  <textarea
                    name="message"
                    required
                    rows={5}
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell us about your space and cleaning needs..."
                    className="w-full px-4 py-3.5 rounded-xl border border-gold-200/60 bg-cream/50 text-charcoal placeholder:text-charcoal/30 focus:outline-none focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 transition-all font-body resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gold-500 text-white px-8 py-4 rounded-xl font-heading font-semibold hover:bg-gold-600 transition-all shadow-lg shadow-gold-500/20 hover:shadow-xl"
                >
                  <Send className="w-4 h-4" />
                  Send Message
                </button>
              </form>
            )}
          </motion.div>

          {/* Contact Info Cards - Takes 2 columns */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2 space-y-4"
          >
            {contactInfo.map((c, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-5 rounded-2xl bg-gold-50/60 border border-gold-100/50 hover:border-gold-200 transition-colors"
              >
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl bg-gold-100 flex items-center justify-center shrink-0">
                    <c.icon className="w-5 h-5 text-gold-600" />
                  </div>
                  <div>
                    <p className="text-xs font-heading text-charcoal/40 uppercase tracking-wider mb-1">{c.label}</p>
                    {c.href ? (
                      <a href={c.href} className="font-heading font-semibold text-charcoal hover:text-gold-600 transition-colors block">
                        {c.value}
                      </a>
                    ) : (
                      <p className="font-heading font-semibold text-charcoal">{c.value}</p>
                    )}
                    <p className="text-xs text-charcoal/40 mt-0.5">{c.sub}</p>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Quick WhatsApp CTA */}
            <motion.a
              href="https://wa.me/263771234567"
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="flex items-center justify-center gap-3 w-full p-5 rounded-2xl bg-emerald-600 text-white font-heading font-semibold hover:bg-emerald-700 transition-colors shadow-lg"
            >
              <MessageCircle className="w-5 h-5" />
              Chat on WhatsApp
            </motion.a>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

/* ============================================
   MAP SECTION
   Vision: Full-width decorative map area with a
   gold-tinted overlay and location pin marker.
   Since we can't embed Google Maps without a key,
   this is a styled placeholder.
   Image: Aerial/satellite view of Harare city or
   an elegant city map illustration.
============================================ */
function MapSection() {
  return (
    <section className="relative h-[400px] bg-gold-100" id="map">
      {/* Vision: Aerial photo of Harare city with golden overlay tint */}
      <img
        src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=1200&q=80"
        alt="Location map — Harare, Zimbabwe"
        className="w-full h-full object-cover opacity-40"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-gold-100/30" />
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="w-16 h-16 bg-gold-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-gold-500/30">
            <MapPin className="w-7 h-7 text-white" />
          </div>
          <h3 className="font-display text-2xl font-bold text-charcoal mb-1">Brite Shine HQ</h3>
          <p className="text-charcoal/60">123 Shine Avenue, Business District, Harare</p>
        </motion.div>
      </div>
    </section>
  )
}
