import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ZoomIn, Camera, Filter } from 'lucide-react'

const CATEGORIES = ['All', 'Residential', 'Commercial', 'Before & After', 'Deep Clean']

/* Vision for each gallery item: High-quality before/after shots, pristine interiors,
   team action shots. Mix of wide and tight compositions. */
const GALLERY = [
  { src: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&q=80', cat: 'Residential', title: 'Modern Living Room Transformation', tall: true },
  { src: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80', cat: 'Commercial', title: 'Corporate Office Deep Clean' },
  { src: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80', cat: 'Residential', title: 'Luxury Home Interior' },
  { src: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80', cat: 'Deep Clean', title: 'Kitchen Deep Sanitization', tall: true },
  { src: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80', cat: 'Before & After', title: 'Whole-Home Makeover' },
  { src: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=800&q=80', cat: 'Before & After', title: 'Move-Out Clean Result' },
  { src: 'https://images.unsplash.com/photo-1600573472592-401b489a3cdc?w=800&q=80', cat: 'Residential', title: 'Bathroom Revival' },
  { src: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800&q=80', cat: 'Commercial', title: 'Retail Space Refresh', tall: true },
  { src: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&q=80', cat: 'Residential', title: 'Minimalist Bedroom Clean' },
  { src: 'https://images.unsplash.com/photo-1556909172-54557c7e4fb7?w=800&q=80', cat: 'Deep Clean', title: 'Industrial Kitchen Scrub' },
  { src: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&q=80', cat: 'Residential', title: 'Open Plan Living Space' },
  { src: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800&q=80', cat: 'Commercial', title: 'Conference Room Polish' },
]

export default function Gallery() {
  const [filter, setFilter] = useState('All')
  const [lightbox, setLightbox] = useState(null)

  const filtered = filter === 'All' ? GALLERY : GALLERY.filter(g => g.cat === filter)

  return (
    <>
      {/* ============================================
         GALLERY HERO
         Vision: Minimal hero with a camera/portfolio
         icon, large text, and the category filter
         integrated into the hero bottom.
      ============================================ */}
      <section className="relative bg-hero-pattern pt-32 pb-12 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-gold mb-6">
              <Camera className="w-4 h-4 text-gold-500" />
              <span className="text-sm font-heading font-medium text-gold-700">Our Portfolio</span>
            </div>
            <h1 className="font-display text-5xl sm:text-6xl font-bold mb-6">
              <span className="text-charcoal">See Our Work</span>
              <br />
              <span className="text-gradient-gold">Speak For Itself</span>
            </h1>
            <p className="text-charcoal/60 text-lg max-w-xl mx-auto mb-12">
              Browse through our collection of transformations. Every image tells a story of dedication and excellence.
            </p>
          </motion.div>

          {/* Filter Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-wrap justify-center gap-2"
          >
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-5 py-2.5 rounded-full text-sm font-heading font-medium transition-all duration-300 ${
                  filter === cat
                    ? 'bg-charcoal text-white shadow-lg'
                    : 'bg-white text-charcoal/60 hover:text-charcoal hover:bg-gold-50 border border-gold-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ============================================
         MASONRY GALLERY GRID
         Vision: Pinterest-style masonry with varied
         heights. Hover reveals title and zoom icon.
         Smooth filter transitions.
      ============================================ */}
      <section className="py-16 bg-cream">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div layout className="columns-1 sm:columns-2 lg:columns-3 gap-5 space-y-5">
            <AnimatePresence mode="popLayout">
              {filtered.map((item, i) => (
                <motion.div
                  key={item.src}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4, delay: i * 0.03 }}
                  className="break-inside-avoid group cursor-pointer relative rounded-2xl overflow-hidden"
                  onClick={() => setLightbox(item)}
                >
                  <img
                    src={item.src}
                    alt={item.title}
                    className={`w-full object-cover group-hover:scale-105 transition-transform duration-700 ${
                      item.tall ? 'h-[450px]' : 'h-[300px]'
                    }`}
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <span className="inline-block px-3 py-1 bg-gold-500/80 text-white text-xs font-heading rounded-full mb-2">{item.cat}</span>
                    <h3 className="text-white font-heading font-semibold text-lg">{item.title}</h3>
                  </div>
                  <div className="absolute top-4 right-4 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <ZoomIn className="w-4 h-4 text-charcoal" />
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-charcoal/90 backdrop-blur-md z-[70] flex items-center justify-center p-4"
            onClick={() => setLightbox(null)}
          >
            <button
              onClick={() => setLightbox(null)}
              className="absolute top-6 right-6 w-12 h-12 bg-white/10 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="max-w-4xl w-full"
              onClick={e => e.stopPropagation()}
            >
              <img
                src={lightbox.src}
                alt={lightbox.title}
                className="w-full max-h-[80vh] object-contain rounded-xl"
              />
              <div className="mt-4 text-center">
                <span className="inline-block px-3 py-1 bg-gold-500/30 text-gold-300 text-xs font-heading rounded-full mb-2">{lightbox.cat}</span>
                <h3 className="text-white font-display text-xl font-bold">{lightbox.title}</h3>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
