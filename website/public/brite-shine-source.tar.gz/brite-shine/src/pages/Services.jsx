import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Home as HomeIcon, Building2, SprayCan, Truck, Wind, Sparkles, Check, ArrowRight, Star, ChevronDown, Droplets, Brush } from 'lucide-react'
import { useInView } from '../hooks/useIntersectionObserver'

export default function Services() {
  return (
    <>
      <ServicesHero />
      <ServicesList />
      <PricingSection />
      <FAQSection />
    </>
  )
}

/* ============================================
   SERVICES HERO
   Vision: Diagonal split design with a dramatic angle.
   Left side cream with text, right side has a full-bleed
   image cropped at an angle. Bold and dynamic.
   Image: Overhead/aerial shot of cleaning supplies
   arranged artistically — a flat-lay composition.
============================================ */
function ServicesHero() {
  return (
    <section className="relative min-h-[60vh] flex items-end bg-hero-pattern pt-32 pb-20 overflow-hidden">
      {/* Diagonal Image Background — right side */}
      <div className="absolute top-0 right-0 w-1/2 h-full hidden lg:block">
        <div className="absolute inset-0 bg-gold-100/30" style={{ clipPath: 'polygon(15% 0, 100% 0, 100% 100%, 0% 100%)' }}>
          {/* Vision: Beautiful flat-lay of premium cleaning products, microfiber cloths, sprays, arranged on marble */}
          <img
            src="https://images.unsplash.com/photo-1563453392212-326f5e854473?w=800&q=80"
            alt="Premium cleaning supplies"
            className="w-full h-full object-cover opacity-60"
            loading="eager"
          />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-gold mb-6">
            <SprayCan className="w-4 h-4 text-gold-500" />
            <span className="text-sm font-heading font-medium text-gold-700">Our Services</span>
          </div>
          <h1 className="font-display text-5xl sm:text-6xl font-bold leading-tight mb-6">
            <span className="text-charcoal">Cleaning Solutions</span>
            <br />
            <span className="text-gradient-gold">For Every Need</span>
          </h1>
          <p className="text-charcoal/60 text-lg leading-relaxed max-w-xl">
            From routine maintenance to deep sanitization, explore our comprehensive range of professional cleaning services.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

/* ============================================
   SERVICES LIST
   Vision: Alternating layout — each service has a
   large detailed card with image on alternate sides.
   Full description, features list, and CTA.
============================================ */
function ServicesList() {
  const services = [
    {
      icon: HomeIcon,
      title: 'Residential Cleaning',
      tagline: 'Your home, our priority',
      desc: 'Experience the joy of coming home to a pristine living space. Our residential cleaning covers every room, surface, and corner of your home with meticulous attention.',
      features: ['Kitchen & bathroom deep clean', 'Dusting all surfaces & fixtures', 'Vacuuming & mopping all floors', 'Window sill & baseboard cleaning', 'Bed making & linen change', 'Trash removal & recycling'],
      img: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=700&q=80',
      // Vision: Bright living room with fresh flowers, gleaming hardwood floors, plush couch cushions
    },
    {
      icon: Building2,
      title: 'Commercial Cleaning',
      tagline: 'Impress at first glance',
      desc: 'A clean workspace boosts productivity and impresses clients. Our commercial cleaning services are tailored to offices, retail spaces, and corporate environments.',
      features: ['Workspace & desk sanitization', 'Restroom deep cleaning', 'Break room & kitchen cleaning', 'Floor care & carpet maintenance', 'Window & glass cleaning', 'Customizable schedules'],
      img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=700&q=80',
      // Vision: Modern open-plan office, clean glass partitions, organized desks
    },
    {
      icon: SprayCan,
      title: 'Deep Cleaning',
      tagline: 'Beyond surface level',
      desc: 'Our intensive deep cleaning tackles the hidden grime — behind appliances, inside cabinets, under furniture. Perfect for seasonal refreshes or special occasions.',
      features: ['Inside oven & refrigerator', 'Behind & under appliances', 'Light fixture cleaning', 'Cabinet interior wipe-down', 'Grout & tile scrubbing', 'Air vent dusting'],
      img: 'https://images.unsplash.com/photo-1628177142898-93e36e4e3a50?w=700&q=80',
      // Vision: Gleaming kitchen — sparkling countertops, pristine stovetop, organized shelves
    },
    {
      icon: Truck,
      title: 'Move-In/Out Cleaning',
      tagline: 'Start fresh, leave clean',
      desc: 'Whether you\'re settling into a new space or handing over the keys, our move cleaning ensures every surface is immaculate for the next chapter.',
      features: ['Full property deep clean', 'Appliance interior cleaning', 'Closet & storage cleaning', 'Wall spot cleaning', 'Fixture polishing', 'Final walkthrough inspection'],
      img: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=700&q=80',
      // Vision: Empty apartment with gleaming hardwood, bright windows, ready for new occupant
    },
    {
      icon: Wind,
      title: 'Carpet & Upholstery',
      tagline: 'Revive your fabrics',
      desc: 'Professional hot-water extraction and steam cleaning that removes deep-set dirt, allergens, and stains from carpets, rugs, and upholstered furniture.',
      features: ['Hot water extraction', 'Stain pre-treatment', 'Deodorizing treatment', 'Fabric protection application', 'Pet stain & odor removal', 'Quick-dry technology'],
      img: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=700&q=80',
      // Vision: Close-up of clean plush carpet texture, or before/after upholstery cleaning
    },
    {
      icon: Droplets,
      title: 'Sanitization Services',
      tagline: 'Health-first cleaning',
      desc: 'Hospital-grade sanitization for homes, offices, and commercial spaces. Ideal for post-illness cleaning, daycare centers, and health-conscious clients.',
      features: ['EPA-approved disinfectants', 'High-touch surface focus', 'Electrostatic spraying', 'Air quality improvement', 'Allergen reduction', 'Certification provided'],
      img: 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=700&q=80',
      // Vision: Professional in PPE sanitizing a modern space, clinical yet reassuring
    },
  ]

  return (
    <section className="py-24 sm:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-24">
          {services.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.6 }}
              className={`grid lg:grid-cols-2 gap-12 lg:gap-20 items-center ${
                i % 2 !== 0 ? 'lg:direction-rtl' : ''
              }`}
              style={i % 2 !== 0 ? { direction: 'rtl' } : {}}
            >
              {/* Image */}
              <div className="relative" style={{ direction: 'ltr' }}>
                <div className="rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src={s.img}
                    alt={s.title}
                    className="w-full h-[380px] object-cover hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                </div>
                <div className="absolute -bottom-4 -right-4 bg-gold-500 text-white px-5 py-3 rounded-xl shadow-lg font-heading font-semibold text-sm hidden sm:block">
                  {s.tagline}
                </div>
              </div>

              {/* Content */}
              <div style={{ direction: 'ltr' }}>
                <div className="w-14 h-14 rounded-2xl bg-gold-100 flex items-center justify-center mb-5">
                  <s.icon className="w-7 h-7 text-gold-600" />
                </div>
                <h2 className="font-display text-3xl font-bold text-charcoal mb-3">{s.title}</h2>
                <p className="text-charcoal/60 leading-relaxed mb-6">{s.desc}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                  {s.features.map((f, j) => (
                    <div key={j} className="flex items-center gap-2 text-sm text-charcoal/70">
                      <Check className="w-4 h-4 text-gold-500 shrink-0" />
                      {f}
                    </div>
                  ))}
                </div>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 bg-charcoal text-white px-6 py-3 rounded-full text-sm font-heading font-medium hover:bg-gold-700 transition-colors"
                >
                  Book This Service <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   PRICING SECTION
   Vision: Three-tier pricing cards with the middle
   card elevated/highlighted. Clean, clear, with
   gold accents on the premium tier.
============================================ */
function PricingSection() {
  const plans = [
    {
      name: 'Basic',
      price: '$30',
      period: '/session',
      desc: 'Perfect for regular upkeep of small spaces.',
      features: ['Cleaning bathrooms', 'Kitchen surfaces', 'Vacuuming carpets and rugs', 'Mopping & wiping surfaces', 'Dusting all rooms'],
      popular: false,
    },
    {
      name: 'Standard',
      price: '$70',
      period: '/session',
      desc: 'Our most popular package for thorough home cleaning.',
      features: ['All services from Basic', 'Inside fridge & oven', 'Cleaning inside cupboards', 'Window cleaning (interior)', 'Laundry folding', 'Bed making'],
      popular: true,
    },
    {
      name: 'Premium',
      price: '$120',
      period: '/session',
      desc: 'The ultimate cleaning experience — no surface untouched.',
      features: ['All services from Standard', 'Cleaning inside closets', 'Organizing storage areas', 'High-reach surfaces', 'Appliance deep clean', 'Post-clean inspection'],
      popular: false,
    },
  ]

  return (
    <section className="py-24 sm:py-32 bg-cream" id="pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-sm font-heading font-semibold text-gold-600 uppercase tracking-widest mb-4 block"
          >
            Pricing
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl sm:text-5xl font-bold text-charcoal"
          >
            Choose Your <span className="text-gradient-gold">Perfect Clean</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 max-w-5xl mx-auto">
          {plans.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`relative rounded-2xl p-8 transition-all duration-300 ${
                p.popular
                  ? 'bg-charcoal text-white shadow-2xl scale-[1.02] lg:scale-105 z-10'
                  : 'bg-white border border-gold-100 hover:shadow-lg'
              }`}
            >
              {p.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gold-500 text-white px-4 py-1 rounded-full text-xs font-heading font-semibold flex items-center gap-1">
                  <Star className="w-3 h-3 fill-white" /> Most Popular
                </div>
              )}
              <h3 className={`font-heading text-lg font-semibold mb-2 ${p.popular ? 'text-gold-400' : 'text-charcoal'}`}>
                {p.name}
              </h3>
              <div className="flex items-baseline gap-1 mb-2">
                <span className={`font-display text-4xl font-bold ${p.popular ? 'text-white' : 'text-charcoal'}`}>
                  {p.price}
                </span>
                <span className={`text-sm ${p.popular ? 'text-white/50' : 'text-charcoal/40'}`}>{p.period}</span>
              </div>
              <p className={`text-sm mb-6 ${p.popular ? 'text-white/60' : 'text-charcoal/50'}`}>{p.desc}</p>
              <div className="space-y-3 mb-8">
                {p.features.map((f, j) => (
                  <div key={j} className="flex items-center gap-2 text-sm">
                    <Check className={`w-4 h-4 shrink-0 ${p.popular ? 'text-gold-400' : 'text-gold-500'}`} />
                    <span className={p.popular ? 'text-white/80' : 'text-charcoal/70'}>{f}</span>
                  </div>
                ))}
              </div>
              <Link
                to="/contact"
                className={`block text-center py-3 rounded-xl font-heading font-semibold text-sm transition-all ${
                  p.popular
                    ? 'bg-gold-500 text-white hover:bg-gold-600 shadow-lg shadow-gold-500/25'
                    : 'border border-gold-300 text-gold-700 hover:bg-gold-50'
                }`}
              >
                Get Started
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   FAQ SECTION
   Vision: Clean accordion-style FAQ with smooth
   expand/collapse animations.
============================================ */
function FAQSection() {
  const [open, setOpen] = useState(null)
  const faqs = [
    { q: 'How do I book a cleaning session?', a: 'You can book through our website\'s contact form, call us directly, or send a WhatsApp message. We\'ll confirm your appointment within 2 hours.' },
    { q: 'Are your cleaning products safe for children and pets?', a: 'Absolutely! We exclusively use eco-certified, non-toxic, and biodegradable cleaning products that are safe for your entire family, including children and pets.' },
    { q: 'Do I need to provide cleaning supplies?', a: 'No — our team arrives fully equipped with all professional-grade cleaning supplies and equipment. You don\'t need to provide anything.' },
    { q: 'What if I\'m not satisfied with the cleaning?', a: 'Your satisfaction is guaranteed. If you\'re not happy with any aspect of our service, we\'ll return within 24 hours to re-clean the area at no additional cost.' },
    { q: 'How long does a typical cleaning session take?', a: 'It depends on the size and condition of your space. A standard residential clean typically takes 2-4 hours, while deep cleans may take 4-6 hours.' },
  ]

  return (
    <section className="py-24 sm:py-32 bg-white" id="faq">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl font-bold text-charcoal"
          >
            Frequently Asked <span className="text-gradient-gold">Questions</span>
          </motion.h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="border border-gold-100 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between px-6 py-5 text-left hover:bg-gold-50/50 transition-colors"
              >
                <span className="font-heading font-medium text-charcoal pr-4">{faq.q}</span>
                <ChevronDown className={`w-5 h-5 text-gold-500 shrink-0 transition-transform duration-300 ${open === i ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-5 text-charcoal/60 text-sm leading-relaxed">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
