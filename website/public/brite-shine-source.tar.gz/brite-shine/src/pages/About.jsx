import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Heart, Target, Eye, Users, Award, Leaf, Shield, ArrowRight, Quote } from 'lucide-react'
import { useInView } from '../hooks/useIntersectionObserver'

/* SEO meta handled in App-level Helmet or document.title */
export default function About() {
  return (
    <>
      <AboutHero />
      <StorySection />
      <ValuesSection />
      <TeamSection />
      <TimelineSection />
      <AboutCTA />
    </>
  )
}

/* ============================================
   ABOUT HERO
   Vision: Split design — left half has bold typography
   on a cream background, right half has a large
   portrait-style image of the team or founder.
   Image: Group photo of diverse cleaning team in
   branded uniforms, smiling confidently.
============================================ */
function AboutHero() {
  return (
    <section className="relative min-h-[70vh] flex items-end overflow-hidden bg-hero-pattern pt-32 pb-20">
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          animate={{ x: [0, 20, 0] }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute top-40 right-20 w-80 h-80 bg-gold-200/20 rounded-full blur-[80px]"
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative w-full">
        <div className="grid lg:grid-cols-5 gap-12 items-end">
          <div className="lg:col-span-3">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-gold mb-6"
            >
              <Heart className="w-4 h-4 text-gold-500" />
              <span className="text-sm font-heading font-medium text-gold-700">About Brite Shine</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.05] mb-6"
            >
              <span className="text-charcoal">A Passion For</span>
              <br />
              <span className="text-gradient-gold">Spotless Spaces</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-charcoal/60 text-lg max-w-xl leading-relaxed"
            >
              Founded in 2015, Brite Shine has grown from a small family operation into the region's most trusted cleaning service — all while keeping the personal touch that makes us special.
            </motion.p>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
            className="lg:col-span-2 hidden lg:block"
          >
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              {/* Vision: Founder or lead team member in branded attire, warm natural lighting, professional portrait style */}
              <img
                src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=600&q=80"
                alt="Brite Shine team"
                className="w-full h-[400px] object-cover"
                loading="eager"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

/* ============================================
   STORY SECTION
   Vision: Magazine-editorial layout with a large
   pull-quote, narrative text, and accent image.
============================================ */
function StorySection() {
  const [ref, inView] = useInView()

  return (
    <section className="py-24 sm:py-32 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            className="relative"
          >
            <div className="rounded-2xl overflow-hidden">
              {/* Vision: Team members working together, cleaning a bright modern space. Candid, warm, showing teamwork and dedication */}
              <img
                src="https://images.unsplash.com/photo-1521791136064-7986c2920216?w=700&q=80"
                alt="Our story — working together"
                className="w-full h-[500px] object-cover"
                loading="lazy"
              />
            </div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ delay: 0.4 }}
              className="absolute -bottom-6 -right-6 bg-gold-500 text-white p-6 rounded-2xl max-w-xs shadow-lg hidden sm:block"
            >
              <Quote className="w-6 h-6 text-gold-200 mb-2" />
              <p className="font-display text-lg italic leading-relaxed">
                "We don't cut corners, we clean them."
              </p>
              <p className="text-gold-200 text-sm mt-2 font-heading">— Our Founding Promise</p>
            </motion.div>
          </motion.div>

          {/* Text side */}
          <div>
            <motion.span
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              className="text-sm font-heading font-semibold text-gold-600 uppercase tracking-widest mb-4 block"
            >
              Our Story
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              className="font-display text-4xl font-bold text-charcoal mb-6"
            >
              Born From a Simple <span className="text-gradient-gold">Belief</span>
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.15 }}
              className="space-y-4 text-charcoal/60 leading-relaxed"
            >
              <p>It started with a mop, a bucket, and an unwavering belief that every space deserves to shine. Our founder began Brite Shine Cleaning Services in 2015, driven by a vision to elevate the standard of professional cleaning.</p>
              <p>What began as weekend cleanings for neighbors quickly grew into a full-service operation. Today, we serve over 800 residential and commercial clients with a team of 50+ trained professionals, but our philosophy remains the same — no job is done until it sparkles.</p>
              <p>We invest in our people, our products, and our processes. Every team member undergoes 80+ hours of training, and we exclusively use eco-certified cleaning solutions. Because at Brite Shine, excellence isn't just a goal — it's our standard.</p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ============================================
   VALUES SECTION
   Vision: Card grid with icons and a warm gold
   accent. Asymmetric layout with one large card
   and smaller cards.
============================================ */
function ValuesSection() {
  const values = [
    { icon: Target, title: 'Excellence', desc: 'We set the highest standards and then exceed them. Every clean is our best clean.' },
    { icon: Heart, title: 'Care', desc: 'We treat every space as if it were our own, with genuine care and respect.' },
    { icon: Shield, title: 'Integrity', desc: 'Honest pricing, reliable service, and transparent communication — always.' },
    { icon: Leaf, title: 'Sustainability', desc: 'Eco-friendly practices that protect your family and the environment.' },
    { icon: Users, title: 'Community', desc: 'We invest in our team and our community, creating opportunities that uplift.' },
    { icon: Eye, title: 'Attention to Detail', desc: 'The corners, the edges, the spots others miss — that\'s where we shine.' },
  ]

  return (
    <section className="py-24 sm:py-32 bg-cream relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl sm:text-5xl font-bold text-charcoal"
          >
            Our Core <span className="text-gradient-gold">Values</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {values.map((v, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="group bg-white rounded-2xl p-8 hover:shadow-lg transition-all duration-300 border border-gold-100/50 hover:border-gold-200/80"
            >
              <div className="w-14 h-14 rounded-2xl bg-gold-100 flex items-center justify-center mb-5 group-hover:bg-gold-500 transition-colors duration-300">
                <v.icon className="w-6 h-6 text-gold-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="font-heading text-lg font-semibold text-charcoal mb-2">{v.title}</h3>
              <p className="text-charcoal/50 text-sm leading-relaxed">{v.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   TEAM SECTION
   Vision: Clean grid of team member cards with
   hover reveal for roles/descriptions. Warm,
   approachable photography style.
============================================ */
function TeamSection() {
  const team = [
    { name: 'Grace Moyo', role: 'Founder & CEO', img: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400&q=80' },
    { name: 'Tendai Nkomo', role: 'Operations Director', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80' },
    { name: 'Rudo Chisango', role: 'Head of Training', img: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&q=80' },
    { name: 'Farai Dube', role: 'Client Relations', img: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=80' },
  ]

  return (
    <section className="py-24 sm:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl sm:text-5xl font-bold text-charcoal"
          >
            Meet Our <span className="text-gradient-gold">Leadership</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-charcoal/50 mt-4 max-w-xl mx-auto text-lg"
          >
            The passionate people behind every spotless space.
          </motion.p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group"
            >
              <div className="relative rounded-2xl overflow-hidden mb-4 aspect-[3/4]">
                {/* Vision: Professional, approachable headshots with warm lighting and neutral backgrounds */}
                <img
                  src={t.img}
                  alt={t.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
              <h3 className="font-heading font-semibold text-charcoal">{t.name}</h3>
              <p className="text-sm text-gold-600">{t.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   TIMELINE SECTION
   Vision: Vertical timeline with alternating left/right
   cards showing company milestones. Golden dots and
   connecting line.
============================================ */
function TimelineSection() {
  const milestones = [
    { year: '2015', title: 'The Beginning', desc: 'Founded with just 3 team members and a commitment to spotless cleaning.' },
    { year: '2017', title: 'First 100 Clients', desc: 'Reached our first major milestone, proving demand for premium cleaning.' },
    { year: '2019', title: 'Commercial Division', desc: 'Expanded into office and commercial cleaning, doubling our team.' },
    { year: '2021', title: 'Green Certified', desc: 'Achieved eco-certification, transitioning to 100% green cleaning products.' },
    { year: '2023', title: '500+ Clients', desc: 'Half a thousand clients trusting us with their spaces regularly.' },
    { year: '2025', title: '800+ & Growing', desc: 'Awarded "Best Cleaning Service" and launched our premium tier.' },
  ]

  return (
    <section className="py-24 sm:py-32 bg-charcoal relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl sm:text-5xl font-bold text-white"
          >
            Our <span className="text-gold-400">Journey</span>
          </motion.h2>
        </div>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-4 sm:left-1/2 top-0 bottom-0 w-px bg-gold-500/20 sm:-translate-x-px" />

          <div className="space-y-12">
            {milestones.map((m, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`relative flex items-start gap-8 ${
                  i % 2 === 0 ? 'sm:flex-row' : 'sm:flex-row-reverse'
                }`}
              >
                {/* Dot */}
                <div className="absolute left-4 sm:left-1/2 w-3 h-3 bg-gold-500 rounded-full -translate-x-1.5 sm:-translate-x-1.5 mt-2 shadow-lg shadow-gold-500/30 z-10" />

                {/* Card */}
                <div className={`ml-12 sm:ml-0 sm:w-[calc(50%-2rem)] ${i % 2 === 0 ? 'sm:pr-8 sm:text-right' : 'sm:pl-8'}`}>
                  <span className="text-gold-400 font-display text-2xl font-bold">{m.year}</span>
                  <h3 className="font-heading text-lg font-semibold text-white mt-1 mb-2">{m.title}</h3>
                  <p className="text-white/40 text-sm leading-relaxed">{m.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function AboutCTA() {
  return (
    <section className="py-20 bg-gold-50/50">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-charcoal mb-4">
            Ready to Experience the Difference?
          </h2>
          <p className="text-charcoal/50 text-lg mb-8">
            Join our growing family of happy clients today.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 bg-gold-500 text-white px-8 py-4 rounded-full font-heading font-semibold hover:bg-gold-600 transition-all shadow-lg shadow-gold-500/25"
          >
            Get Started <ArrowRight className="w-5 h-5" />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
