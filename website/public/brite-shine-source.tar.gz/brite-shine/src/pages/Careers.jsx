import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Briefcase, MapPin, Clock, ChevronDown, ArrowRight, Heart, GraduationCap, DollarSign, Users, Sparkles, Shield } from 'lucide-react'
import { useInView } from '../hooks/useIntersectionObserver'

const JOBS = [
  {
    title: 'Senior Cleaning Technician',
    dept: 'Operations',
    location: 'Harare',
    type: 'Full-time',
    desc: 'Lead cleaning teams on residential and commercial projects. 3+ years experience required. Excellent attention to detail and leadership skills.',
    responsibilities: ['Lead a team of 3-5 cleaners', 'Quality inspection and sign-off', 'Client communication and relationship management', 'Training new team members'],
  },
  {
    title: 'Residential Cleaning Specialist',
    dept: 'Residential Division',
    location: 'Harare',
    type: 'Full-time',
    desc: 'Join our residential team delivering exceptional home cleaning services. Training provided. Must be reliable, detail-oriented, and customer-focused.',
    responsibilities: ['Perform thorough residential cleaning', 'Follow Brite Shine cleaning protocols', 'Maintain cleaning equipment', 'Provide excellent customer service'],
  },
  {
    title: 'Commercial Cleaning Operative',
    dept: 'Commercial Division',
    location: 'Harare',
    type: 'Full-time / Part-time',
    desc: 'Clean offices, retail spaces, and commercial buildings. Flexible shifts available including evenings and weekends.',
    responsibilities: ['Clean and sanitize commercial spaces', 'Operate industrial cleaning equipment', 'Follow health and safety protocols', 'Report maintenance issues'],
  },
  {
    title: 'Client Relations Coordinator',
    dept: 'Customer Service',
    location: 'Harare (Office)',
    type: 'Full-time',
    desc: 'Be the voice of Brite Shine. Handle bookings, respond to inquiries, and ensure every client receives a world-class experience.',
    responsibilities: ['Manage booking system and schedules', 'Handle client inquiries and complaints', 'Coordinate with cleaning teams', 'Maintain client database'],
  },
  {
    title: 'Marketing & Social Media Manager',
    dept: 'Marketing',
    location: 'Harare (Hybrid)',
    type: 'Full-time',
    desc: 'Drive brand awareness and growth through creative digital marketing campaigns, social media management, and content creation.',
    responsibilities: ['Manage social media accounts', 'Create engaging content', 'Run digital ad campaigns', 'Analyze performance metrics'],
  },
]

const PERKS = [
  { icon: DollarSign, title: 'Competitive Pay', desc: 'Above-market salary with performance bonuses and tips.' },
  { icon: GraduationCap, title: 'Paid Training', desc: '80+ hours of professional training and ongoing development.' },
  { icon: Heart, title: 'Health Benefits', desc: 'Medical aid contribution and wellness program access.' },
  { icon: Shield, title: 'Equipment Provided', desc: 'All tools, uniforms, and supplies provided at no cost.' },
  { icon: Users, title: 'Team Culture', desc: 'Monthly team events, birthdays celebrated, and a family atmosphere.' },
  { icon: Sparkles, title: 'Growth Path', desc: 'Clear promotion pathways from cleaner to team lead to manager.' },
]

export default function Careers() {
  const [expanded, setExpanded] = useState(null)

  return (
    <>
      {/* ============================================
         CAREERS HERO
         Vision: Warm, people-focused hero with a large
         background image of the team. Gradient overlay
         with centered text. Inspiring and inviting.
         Image: Diverse team of cleaners, smiling,
         standing together outdoors in uniform.
      ============================================ */}
      <section className="relative min-h-[70vh] flex items-center overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&q=80"
          alt="Join our team"
          className="absolute inset-0 w-full h-full object-cover"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal/85 via-charcoal/60 to-charcoal/30" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
              <Briefcase className="w-4 h-4 text-gold-400" />
              <span className="text-sm font-heading font-medium text-gold-300">Careers at Brite Shine</span>
            </div>
            <h1 className="font-display text-5xl sm:text-6xl font-bold text-white leading-tight mb-6">
              Build Your Career
              <br />
              <span className="text-gold-400">With Purpose</span>
            </h1>
            <p className="text-white/60 text-lg leading-relaxed max-w-xl">
              Join a team that takes pride in transforming spaces. We invest in our people because we know that great teams create great results.
            </p>
          </motion.div>
        </div>
      </section>

      {/* ============================================
         PERKS & BENEFITS
         Vision: Horizontal scrolling cards on mobile,
         3-column grid on desktop. Warm icons with
         gold accent backgrounds.
      ============================================ */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="font-display text-4xl font-bold text-charcoal"
            >
              Why Work <span className="text-gradient-gold">With Us</span>
            </motion.h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {PERKS.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="flex gap-4 p-6 rounded-2xl bg-gold-50/50 border border-gold-100/50 hover:border-gold-200 transition-colors"
              >
                <div className="shrink-0 w-12 h-12 rounded-xl bg-gold-100 flex items-center justify-center">
                  <p.icon className="w-5 h-5 text-gold-600" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-charcoal mb-1">{p.title}</h3>
                  <p className="text-sm text-charcoal/50 leading-relaxed">{p.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================
         JOB LISTINGS
         Vision: Clean, expandable accordion-style cards.
         Each job has a summary row with key info tags,
         and expands to show full description and apply button.
      ============================================ */}
      <section className="py-24 bg-cream">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="font-display text-4xl font-bold text-charcoal"
            >
              Open <span className="text-gradient-gold">Positions</span>
            </motion.h2>
            <p className="text-charcoal/50 mt-4 text-lg">
              {JOBS.length} positions currently available
            </p>
          </div>

          <div className="space-y-4">
            {JOBS.map((job, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="bg-white rounded-2xl border border-gold-100/50 overflow-hidden hover:shadow-md transition-shadow"
              >
                <button
                  onClick={() => setExpanded(expanded === i ? null : i)}
                  className="w-full p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-left"
                >
                  <div>
                    <h3 className="font-heading font-semibold text-charcoal text-lg">{job.title}</h3>
                    <div className="flex flex-wrap items-center gap-3 mt-2">
                      <span className="inline-flex items-center gap-1 text-xs text-charcoal/50">
                        <Briefcase className="w-3 h-3" /> {job.dept}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs text-charcoal/50">
                        <MapPin className="w-3 h-3" /> {job.location}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs text-charcoal/50">
                        <Clock className="w-3 h-3" /> {job.type}
                      </span>
                    </div>
                  </div>
                  <ChevronDown className={`w-5 h-5 text-gold-500 shrink-0 transition-transform duration-300 ${expanded === i ? 'rotate-180' : ''}`} />
                </button>

                <AnimatePresence>
                  {expanded === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="px-6 pb-6 border-t border-gold-50 pt-4">
                        <p className="text-charcoal/60 text-sm leading-relaxed mb-4">{job.desc}</p>
                        <h4 className="font-heading font-semibold text-charcoal text-sm mb-2">Key Responsibilities:</h4>
                        <ul className="space-y-2 mb-6">
                          {job.responsibilities.map((r, j) => (
                            <li key={j} className="flex items-start gap-2 text-sm text-charcoal/60">
                              <div className="w-1.5 h-1.5 rounded-full bg-gold-400 mt-1.5 shrink-0" />
                              {r}
                            </li>
                          ))}
                        </ul>
                        <Link
                          to="/contact"
                          className="inline-flex items-center gap-2 bg-gold-500 text-white px-6 py-3 rounded-xl text-sm font-heading font-semibold hover:bg-gold-600 transition-colors"
                        >
                          Apply Now <ArrowRight className="w-4 h-4" />
                        </Link>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* General Application CTA */}
      <section className="py-20 bg-charcoal">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-3xl font-bold text-white mb-4">
              Don't See Your Perfect Role?
            </h2>
            <p className="text-white/50 text-lg mb-8">
              We're always looking for talented individuals. Send us your CV and we'll keep you in mind.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 bg-gold-500 text-white px-8 py-4 rounded-full font-heading font-semibold hover:bg-gold-600 transition-all shadow-lg shadow-gold-500/25"
            >
              Send Your CV <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </>
  )
}
