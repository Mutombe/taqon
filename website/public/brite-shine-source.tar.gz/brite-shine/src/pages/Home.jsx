import { useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, useScroll, useTransform, useInView as useFramerInView } from 'framer-motion'
import { ArrowRight, Sparkles, Shield, Clock, Award, Users, Star, ChevronRight, Play, CheckCircle2, Droplets, Home as HomeIcon, Building2, Truck, SprayCan, Wind } from 'lucide-react'
import { useInView } from '../hooks/useIntersectionObserver'

/* ============================================
   HERO SECTION
   Vision: Grand, spacious hero with floating elements,
   a large headline with gold gradient text, and a
   subtle parallax image. Think luxury brand meets
   cleaning excellence.
   Image: A bright, airy modern living room that's
   immaculately clean with sunlight streaming through
   large windows.
============================================ */
function HeroSection() {
  const containerRef = useRef(null)
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ['start start', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], [0, 150])
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95])

  return (
    <section ref={containerRef} className="relative min-h-screen flex items-center overflow-hidden bg-hero-pattern">
      {/* Animated background orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ x: [0, 30, 0], y: [0, -20, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          className="absolute top-20 right-[10%] w-[500px] h-[500px] rounded-full bg-gold-200/20 blur-[100px]"
        />
        <motion.div
          animate={{ x: [0, -20, 0], y: [0, 30, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
          className="absolute bottom-20 left-[5%] w-[400px] h-[400px] rounded-full bg-gold-300/10 blur-[80px]"
        />
      </div>

      {/* Decorative geometric elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div style={{ y }} className="absolute top-32 left-[8%] w-20 h-20 border border-gold-300/20 rounded-2xl rotate-12" />
        <motion.div style={{ y: useTransform(scrollYProgress, [0, 1], [0, 80]) }} className="absolute bottom-40 right-[12%] w-16 h-16 border border-gold-400/15 rounded-full" />
        <motion.div style={{ y: useTransform(scrollYProgress, [0, 1], [0, 120]) }} className="absolute top-[45%] right-[5%] w-3 h-3 bg-gold-400/30 rounded-full" />
        <motion.div style={{ y: useTransform(scrollYProgress, [0, 1], [0, 60]) }} className="absolute top-[30%] left-[3%] w-2 h-2 bg-gold-500/40 rounded-full" />
      </div>

      <motion.div style={{ opacity, scale }} className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20 lg:pt-40">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Content */}
          <div className="text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-gold mb-8"
            >
              <Sparkles className="w-4 h-4 text-gold-500" />
              <span className="text-sm font-heading font-medium text-gold-700">Premium Cleaning Excellence</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.05] mb-6"
            >
              <span className="text-charcoal">Where Every</span>
              <br />
              <span className="text-gradient-gold">Surface Shines</span>
              <br />
              <span className="text-charcoal">With Brilliance</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="text-charcoal/60 text-lg sm:text-xl leading-relaxed mb-10 max-w-lg mx-auto lg:mx-0"
            >
              Experience the epitome of cleanliness. We transform spaces into pristine havens with meticulous care, eco-friendly products, and unmatched attention to detail.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Link
                to="/contact"
                className="group inline-flex items-center justify-center gap-2 bg-gold-500 text-white px-8 py-4 rounded-full font-heading font-semibold text-base hover:bg-gold-600 transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-xl hover:shadow-gold-500/30"
              >
                Book a Cleaning
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/services"
                className="group inline-flex items-center justify-center gap-2 glass-gold px-8 py-4 rounded-full font-heading font-semibold text-base text-gold-700 hover:bg-gold-100/60 transition-all"
              >
                <Play className="w-4 h-4" />
                Our Services
              </Link>
            </motion.div>

            {/* Trust Badges */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="mt-12 flex items-center gap-6 justify-center lg:justify-start"
            >
              <div className="flex -space-x-3">
                {[1,2,3,4].map(i => (
                  <div key={i} className="w-10 h-10 rounded-full bg-gold-200 border-2 border-white flex items-center justify-center">
                    {/* Vision: Customer avatars — diverse, smiling faces */}
                    <Users className="w-4 h-4 text-gold-600" />
                  </div>
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1 mb-0.5">
                  {[1,2,3,4,5].map(i => (
                    <Star key={i} className="w-4 h-4 text-gold-500 fill-gold-500" />
                  ))}
                </div>
                <p className="text-sm text-charcoal/50">Trusted by <span className="font-semibold text-charcoal">800+</span> happy clients</p>
              </div>
            </motion.div>
          </div>

          {/* Right: Hero Image Composition */}
          <motion.div
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative hidden lg:block"
          >
            <div className="relative">
              {/* Main image container with decorative frame */}
              <div className="relative rounded-[2rem] overflow-hidden shadow-2xl shadow-gold-900/10">
                {/* Vision: A professional cleaner in a bright modern kitchen, wearing branded uniform, smiling while polishing a countertop. The space should feel bright, luxurious, aspirational. */}
                <img
                  src="https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800&q=80"
                  alt="Professional cleaning service"
                  className="w-full h-[560px] object-cover"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/20 via-transparent to-transparent" />
              </div>

              {/* Floating stats card */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8, type: 'spring' }}
                className="absolute -bottom-6 -left-8 glass rounded-2xl p-5 shadow-xl"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gold-100 flex items-center justify-center">
                    <Award className="w-6 h-6 text-gold-600" />
                  </div>
                  <div>
                    <p className="font-display text-2xl font-bold text-charcoal">10+</p>
                    <p className="text-xs text-charcoal/50 font-heading">Years Excellence</p>
                  </div>
                </div>
              </motion.div>

              {/* Floating badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1, type: 'spring' }}
                className="absolute -top-4 -right-4 glass rounded-2xl p-4 shadow-xl"
              >
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  <span className="text-sm font-heading font-semibold text-charcoal">100% Satisfaction</span>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-6 h-10 rounded-full border-2 border-gold-300/40 flex items-start justify-center p-1.5"
        >
          <div className="w-1.5 h-1.5 bg-gold-400 rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  )
}

/* ============================================
   FLOATING TRUST BAR
   Vision: A horizontal bar with key stats that
   floats over the section boundary, creating
   visual depth between hero and content.
============================================ */
function TrustBar() {
  const [ref, inView] = useInView()
  const stats = [
    { value: '800+', label: 'Happy Clients', icon: Users },
    { value: '180+', label: 'Awards Received', icon: Award },
    { value: '10+', label: 'Years Experience', icon: Clock },
    { value: '99%', label: 'Satisfaction Rate', icon: Star },
  ]

  return (
    <div ref={ref} className="relative z-10 max-w-6xl mx-auto px-4 -mt-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6 }}
        className="bg-white rounded-2xl shadow-xl shadow-gold-900/5 p-6 sm:p-8"
      >
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {stats.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="text-center"
            >
              <s.icon className="w-6 h-6 text-gold-500 mx-auto mb-2" />
              <p className="font-display text-3xl sm:text-4xl font-bold text-charcoal">{s.value}</p>
              <p className="text-sm text-charcoal/50 font-heading mt-1">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}

/* ============================================
   SERVICES PREVIEW
   Vision: Bento-grid layout with asymmetric cards.
   Each service has its own visual personality.
   Mix of large and small cards with hover animations.
   Images: Various cleaning scenarios
============================================ */
function ServicesSection() {
  const [ref, inView] = useInView()
  const services = [
    {
      icon: HomeIcon,
      title: 'Residential Cleaning',
      desc: 'Transform your home into a sparkling sanctuary with our thorough residential cleaning packages.',
      img: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=600&q=80',
      // Vision: Bright, modern living room after cleaning — pristine floors, plumped cushions, natural light
      span: 'lg:col-span-2 lg:row-span-2',
      large: true,
    },
    {
      icon: Building2,
      title: 'Commercial Cleaning',
      desc: 'Keep your workspace pristine and professional with tailored office cleaning solutions.',
      img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80',
      // Vision: Modern open office space, clean desks, polished floors, bright and inviting
    },
    {
      icon: SprayCan,
      title: 'Deep Cleaning',
      desc: 'Intensive cleaning that reaches every corner for a truly immaculate result.',
      img: 'https://images.unsplash.com/photo-1628177142898-93e36e4e3a50?w=600&q=80',
      // Vision: Close-up of gleaming kitchen surface with cleaning products artistically arranged
    },
    {
      icon: Truck,
      title: 'Move-In/Out',
      desc: 'Start fresh in your new space or leave your old one spotless.',
      img: 'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=600&q=80',
      // Vision: Empty apartment with sparkling clean hardwood floors, bright windows
    },
    {
      icon: Wind,
      title: 'Carpet & Upholstery',
      desc: 'Revive your fabrics with professional steam cleaning and stain removal.',
      img: 'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=600&q=80',
      // Vision: Close-up of clean, plush carpet or sofa cushion texture
    },
  ]

  return (
    <section className="py-24 sm:py-32 bg-cream relative" id="services-preview">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            className="inline-block text-sm font-heading font-semibold text-gold-600 uppercase tracking-widest mb-4"
          >
            Our Expertise
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            className="font-display text-4xl sm:text-5xl font-bold text-charcoal mb-4"
          >
            Services Tailored <span className="text-gradient-gold">For You</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-charcoal/50 max-w-2xl mx-auto text-lg"
          >
            From cozy homes to corporate offices, we deliver exceptional cleaning with care and precision.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {services.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className={`group relative rounded-2xl overflow-hidden ${s.span || ''} ${s.large ? 'min-h-[420px]' : 'min-h-[240px]'}`}
            >
              <img
                src={s.img}
                alt={s.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/30 to-transparent" />
              <div className="relative h-full flex flex-col justify-end p-6">
                <s.icon className="w-8 h-8 text-gold-400 mb-3 drop-shadow-lg" />
                <h3 className={`font-display font-bold text-white mb-2 ${s.large ? 'text-2xl' : 'text-lg'}`}>
                  {s.title}
                </h3>
                <p className={`text-white/70 ${s.large ? 'text-base' : 'text-sm'} line-clamp-2`}>
                  {s.desc}
                </p>
                <Link
                  to="/services"
                  className="mt-4 inline-flex items-center gap-1 text-gold-400 text-sm font-heading font-medium group-hover:gap-2 transition-all"
                >
                  Learn More <ChevronRight className="w-4 h-4" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   WHY CHOOSE US
   Vision: Asymmetric two-column layout. Left side has
   a stacked image composition with overlapping photos.
   Right side has elegant feature cards.
   Images: Close-ups of gleaming surfaces, the team in action.
============================================ */
function WhyChooseUs() {
  const [ref, inView] = useInView()
  const features = [
    { icon: Shield, title: 'Trusted & Insured', desc: 'Fully vetted, background-checked team with comprehensive liability coverage for your peace of mind.' },
    { icon: Droplets, title: 'Eco-Friendly Products', desc: 'We use biodegradable, non-toxic cleaning solutions that are safe for your family and the planet.' },
    { icon: Clock, title: 'Flexible Scheduling', desc: 'Book any time that works — evenings, weekends, or holidays. We adapt to your lifestyle seamlessly.' },
    { icon: Award, title: 'Quality Guarantee', desc: 'Not satisfied? We return within 24 hours to re-clean at no extra cost. Your satisfaction is our promise.' },
  ]

  return (
    <section className="py-24 sm:py-32 bg-white relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gold-50/50 rounded-l-[4rem] hidden lg:block" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div ref={ref} className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Left: Image Composition */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="relative">
              {/* Main image */}
              <div className="rounded-2xl overflow-hidden shadow-2xl">
                {/* Vision: Two cleaners working together in a bright kitchen, professional and cheerful */}
                <img
                  src="https://images.unsplash.com/photo-1527515637462-cff94eebd21f?w=700&q=80"
                  alt="Professional cleaning team at work"
                  className="w-full h-[450px] object-cover"
                  loading="lazy"
                />
              </div>
              {/* Overlapping accent image */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.3 }}
                className="absolute -bottom-8 -right-8 w-48 h-48 rounded-2xl overflow-hidden shadow-xl border-4 border-white hidden sm:block"
              >
                {/* Vision: Close-up of gloved hands polishing a glass surface to perfection */}
                <img
                  src="https://images.unsplash.com/photo-1563453392212-326f5e854473?w=300&q=80"
                  alt="Attention to detail in cleaning"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </motion.div>
              {/* Experience badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={inView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.5, type: 'spring' }}
                className="absolute -top-6 -left-6 w-28 h-28 bg-gold-500 rounded-2xl flex flex-col items-center justify-center text-white shadow-lg rotate-3"
              >
                <span className="font-display text-3xl font-bold">10+</span>
                <span className="text-xs font-heading">Years</span>
              </motion.div>
            </div>
          </motion.div>

          {/* Right: Content */}
          <div>
            <motion.span
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              className="inline-block text-sm font-heading font-semibold text-gold-600 uppercase tracking-widest mb-4"
            >
              Why Choose Us
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.1 }}
              className="font-display text-4xl sm:text-5xl font-bold text-charcoal mb-6 leading-tight"
            >
              Cleaning That <span className="text-gradient-gold">Exceeds</span> Expectations
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.15 }}
              className="text-charcoal/60 text-lg leading-relaxed mb-10"
            >
              At Brite Shine, we don't just clean — we elevate spaces. Our expert team combines cutting-edge techniques with genuine care to deliver results that truly shine.
            </motion.p>
            <div className="space-y-5">
              {features.map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 20 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.2 + i * 0.1 }}
                  className="flex gap-4 group"
                >
                  <div className="shrink-0 w-12 h-12 rounded-xl bg-gold-100 flex items-center justify-center group-hover:bg-gold-500 transition-colors duration-300">
                    <f.icon className="w-5 h-5 text-gold-600 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-charcoal mb-1">{f.title}</h4>
                    <p className="text-sm text-charcoal/50 leading-relaxed">{f.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ============================================
   PROCESS SECTION
   Vision: Horizontal step-by-step timeline with
   connected dots and a golden line. Each step has
   a number, icon, and brief description. 
============================================ */
function ProcessSection() {
  const [ref, inView] = useInView()
  const steps = [
    { num: '01', title: 'Request a Quote', desc: 'Tell us about your space and needs through our simple online form or a quick call.' },
    { num: '02', title: 'Custom Plan', desc: 'We create a tailored cleaning plan that fits your schedule, budget, and specific requirements.' },
    { num: '03', title: 'Expert Clean', desc: 'Our trained professionals arrive on time, equipped with premium supplies, and clean to perfection.' },
    { num: '04', title: 'Shine & Enjoy', desc: 'Walk into a spotless space and enjoy the Brite Shine difference. Satisfaction guaranteed.' },
  ]

  return (
    <section className="py-24 sm:py-32 bg-charcoal relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-gold-500/5 rounded-full blur-[80px]" />
        <div className="absolute bottom-20 right-10 w-60 h-60 bg-gold-400/5 rounded-full blur-[60px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div ref={ref} className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            className="inline-block text-sm font-heading font-semibold text-gold-400 uppercase tracking-widest mb-4"
          >
            Our Process
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="font-display text-4xl sm:text-5xl font-bold text-white mb-4"
          >
            How It <span className="text-gold-400">Works</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Connecting line - desktop only */}
          <div className="hidden lg:block absolute top-16 left-[12%] right-[12%] h-px bg-gradient-to-r from-gold-500/20 via-gold-500/40 to-gold-500/20" />

          {steps.map((step, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative text-center"
            >
              <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-full bg-gold-500/10 border border-gold-500/30 mb-6 mx-auto">
                <span className="font-display text-xl font-bold text-gold-400">{step.num}</span>
                <div className="absolute inset-0 rounded-full bg-gold-500/5 animate-ping" style={{ animationDuration: '3s' }} />
              </div>
              <h3 className="font-heading text-lg font-semibold text-white mb-3">{step.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{step.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   TESTIMONIALS
   Vision: Elegant card carousel/grid with client
   photos, star ratings, and quotes. Mix of card
   sizes for visual interest.
============================================ */
function TestimonialsSection() {
  const [ref, inView] = useInView()
  const testimonials = [
    { name: 'Sarah M.', role: 'Homeowner', text: 'Absolutely incredible service! My home has never looked this clean. The team was professional, thorough, and so respectful of our space. I\'m a client for life.', rating: 5 },
    { name: 'James K.', role: 'Office Manager', text: 'We switched to Brite Shine for our office cleaning and the difference is night and day. Consistent quality every single week.', rating: 5 },
    { name: 'Amanda T.', role: 'Property Manager', text: 'They handle all our move-out cleanings. Fast turnarounds, exceptional results, and they always go above and beyond what\'s expected.', rating: 5 },
    { name: 'Michael R.', role: 'Restaurant Owner', text: 'The deep cleaning service is second to none. Our kitchen has never passed health inspections this easily. Truly professional team.', rating: 5 },
  ]

  return (
    <section className="py-24 sm:py-32 bg-gold-50/50 relative overflow-hidden" id="testimonials">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            className="inline-block text-sm font-heading font-semibold text-gold-600 uppercase tracking-widest mb-4"
          >
            Testimonials
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="font-display text-4xl sm:text-5xl font-bold text-charcoal"
          >
            What Our Clients <span className="text-gradient-gold">Say</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-shadow duration-300 ${
                i === 0 ? 'md:col-span-2' : ''
              }`}
            >
              <div className="flex items-center gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-gold-500 fill-gold-500" />
                ))}
              </div>
              <p className={`text-charcoal/70 leading-relaxed mb-6 ${i === 0 ? 'text-lg' : 'text-base'}`}>
                "{t.text}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gold-200 flex items-center justify-center">
                  <span className="font-heading font-bold text-gold-700 text-sm">{t.name[0]}</span>
                </div>
                <div>
                  <p className="font-heading font-semibold text-charcoal text-sm">{t.name}</p>
                  <p className="text-xs text-charcoal/40">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================
   CTA SECTION
   Vision: Full-width image background with overlay
   and a centered call-to-action. Dramatic and inviting.
   Image: An immaculate lobby or living space with
   golden hour lighting creating warmth.
============================================ */
function CTASection() {
  return (
    <section className="relative py-32 overflow-hidden">
      {/* Vision: Grand, clean modern interior with golden sunlight streaming in — could be a hotel lobby, premium residence hallway, or commercial atrium */}
      <img
        src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=80"
        alt="Beautiful clean interior"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-charcoal/60 backdrop-blur-[2px]" />
      <div className="relative max-w-3xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Sparkles className="w-10 h-10 text-gold-400 mx-auto mb-6" />
          <h2 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            Experience the
            <br />
            <span className="text-gold-400">Brite Shine</span> Difference
          </h2>
          <p className="text-white/60 text-lg mb-10 max-w-xl mx-auto">
            Join hundreds of satisfied clients who trust us with their most precious spaces. Your first clean is just a click away.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 bg-gold-500 text-white px-8 py-4 rounded-full font-heading font-semibold hover:bg-gold-600 transition-all shadow-lg shadow-gold-500/25"
            >
              Schedule Your First Clean
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="tel:+263771234567"
              className="inline-flex items-center justify-center gap-2 border border-white/30 text-white px-8 py-4 rounded-full font-heading font-semibold hover:bg-white/10 transition-all"
            >
              Call +263 77 123 4567
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

/* ============================================
   HOME PAGE ASSEMBLY
============================================ */
export default function Home() {
  return (
    <>
      <HeroSection />
      <TrustBar />
      <ServicesSection />
      <WhyChooseUs />
      <ProcessSection />
      <TestimonialsSection />
      <CTASection />
    </>
  )
}
