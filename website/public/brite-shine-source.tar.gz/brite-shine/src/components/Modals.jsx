import { motion, AnimatePresence } from 'framer-motion'
import { X, Shield, Cookie } from 'lucide-react'

export function PolicyModal({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-charcoal/50 backdrop-blur-sm z-[70] flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-5 border-b border-gold-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gold-100 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-gold-600" />
                </div>
                <h2 className="font-display text-xl font-bold text-charcoal">Privacy Policy</h2>
              </div>
              <button onClick={onClose} className="p-2 rounded-full hover:bg-gold-50 transition-colors">
                <X className="w-5 h-5 text-charcoal/60" />
              </button>
            </div>
            <div className="px-6 py-6 overflow-y-auto max-h-[60vh] text-charcoal/70 text-sm leading-relaxed space-y-4">
              <p className="font-heading font-semibold text-charcoal">Last Updated: February 2026</p>
              <p>Brite Shine Cleaning Services ("we," "our," or "us") is committed to protecting your personal information. This policy outlines how we collect, use, and safeguard your data when you interact with our website and services.</p>
              <h3 className="font-heading font-semibold text-charcoal mt-4">Information We Collect</h3>
              <p>We collect information you provide directly, such as your name, email address, phone number, and service address when you request a quote or book a cleaning. We also automatically collect certain information including IP address, browser type, and pages visited through cookies and similar technologies.</p>
              <h3 className="font-heading font-semibold text-charcoal mt-4">How We Use Your Information</h3>
              <p>Your information helps us provide and improve our cleaning services, communicate with you about bookings and promotions, process payments securely, and ensure the safety of our team and clients. We never sell your personal data to third parties.</p>
              <h3 className="font-heading font-semibold text-charcoal mt-4">Data Security</h3>
              <p>We implement industry-standard security measures to protect your data, including encrypted communications, secure data storage, and regular security audits. Access to personal information is restricted to authorized personnel only.</p>
              <h3 className="font-heading font-semibold text-charcoal mt-4">Your Rights</h3>
              <p>You have the right to access, correct, or delete your personal data at any time. To exercise these rights or for any privacy-related inquiries, please contact us at privacy@briteshine.co.zw.</p>
            </div>
            <div className="px-6 py-4 border-t border-gold-100">
              <button
                onClick={onClose}
                className="w-full py-3 bg-charcoal text-white rounded-xl font-heading font-medium hover:bg-gold-700 transition-colors"
              >
                I Understand
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export function CookieModal({ open, onClose }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-charcoal/50 backdrop-blur-sm z-[70] flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-5 border-b border-gold-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gold-100 flex items-center justify-center">
                  <Cookie className="w-5 h-5 text-gold-600" />
                </div>
                <h2 className="font-display text-xl font-bold text-charcoal">Cookie Policy</h2>
              </div>
              <button onClick={onClose} className="p-2 rounded-full hover:bg-gold-50 transition-colors">
                <X className="w-5 h-5 text-charcoal/60" />
              </button>
            </div>
            <div className="px-6 py-6 overflow-y-auto max-h-[60vh] text-charcoal/70 text-sm leading-relaxed space-y-4">
              <p>Our website uses cookies to enhance your browsing experience and provide personalized content.</p>
              <h3 className="font-heading font-semibold text-charcoal">Essential Cookies</h3>
              <p>These are necessary for the website to function properly. They include session cookies for navigation, security tokens, and preference settings. These cannot be disabled.</p>
              <h3 className="font-heading font-semibold text-charcoal">Analytics Cookies</h3>
              <p>We use analytics cookies to understand how visitors interact with our website. This helps us improve our services and user experience. All data is anonymized and aggregated.</p>
              <h3 className="font-heading font-semibold text-charcoal">Marketing Cookies</h3>
              <p>These cookies are used to deliver relevant advertisements and track the effectiveness of our marketing campaigns. You can opt out of marketing cookies at any time.</p>
              <h3 className="font-heading font-semibold text-charcoal">Managing Cookies</h3>
              <p>You can control and manage cookies through your browser settings. Note that disabling certain cookies may affect website functionality.</p>
            </div>
            <div className="px-6 py-4 border-t border-gold-100 flex gap-3">
              <button
                onClick={onClose}
                className="flex-1 py-3 border border-gold-200 text-charcoal rounded-xl font-heading font-medium hover:bg-gold-50 transition-colors"
              >
                Essential Only
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 bg-charcoal text-white rounded-xl font-heading font-medium hover:bg-gold-700 transition-colors"
              >
                Accept All
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export function CookieBanner({ onAccept, onOpenPolicy }) {
  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:bottom-6 sm:max-w-md z-[60] glass-dark rounded-2xl p-5 text-white shadow-2xl"
    >
      <div className="flex items-start gap-3">
        <Cookie className="w-5 h-5 text-gold-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm text-white/80 leading-relaxed mb-4">
            We use cookies to improve your experience. By continuing, you agree to our{' '}
            <button onClick={onOpenPolicy} className="text-gold-400 underline underline-offset-2">cookie policy</button>.
          </p>
          <div className="flex gap-2">
            <button
              onClick={onAccept}
              className="px-4 py-2 bg-gold-500 text-white rounded-lg text-sm font-heading font-medium hover:bg-gold-600 transition-colors"
            >
              Accept All
            </button>
            <button
              onClick={onAccept}
              className="px-4 py-2 border border-white/20 rounded-lg text-sm font-heading text-white/60 hover:text-white hover:border-white/40 transition-colors"
            >
              Essential Only
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
