import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Sparkles, MapPin, Phone, Mail, Clock, ArrowUpRight, Facebook, Instagram, Twitter } from 'lucide-react'

const footerLinks = {
  Company: [
    { label: 'About Us', path: '/about' },
    { label: 'Our Services', path: '/services' },
    { label: 'Gallery', path: '/gallery' },
    { label: 'Careers', path: '/careers' },
    { label: 'Contact', path: '/contact' },
  ],
  Services: [
    { label: 'Residential Cleaning', path: '/services' },
    { label: 'Commercial Cleaning', path: '/services' },
    { label: 'Deep Cleaning', path: '/services' },
    { label: 'Move-In/Out Cleaning', path: '/services' },
    { label: 'Carpet & Upholstery', path: '/services' },
  ],
}

export default function Footer({ onOpenPolicy, onOpenCookies }) {
  return (
    <footer className="relative bg-charcoal text-white overflow-hidden">
      {/* Decorative top wave */}
      <div className="absolute top-0 left-0 right-0 overflow-hidden leading-none">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-16 text-cream">
          <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" fill="currentColor"/>
        </svg>
      </div>

      {/* Gold gradient accent line */}
      <div className="h-px bg-gradient-to-r from-transparent via-gold-500 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        {/* Top CTA Band */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative rounded-2xl bg-gradient-to-r from-gold-600 to-gold-500 p-8 sm:p-12 mb-16 overflow-hidden"
        >
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full -translate-y-1/2 translate-x-1/2" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full translate-y-1/2 -translate-x-1/2" />
          </div>
          <div className="relative flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-white mb-2">
                Ready for a Spotless Space?
              </h3>
              <p className="text-gold-100/80 font-body max-w-md">
                Get your free estimate today. Our experts are standing by to make your space shine.
              </p>
            </div>
            <Link
              to="/contact"
              className="shrink-0 bg-white text-gold-700 px-8 py-4 rounded-full font-heading font-semibold hover:bg-gold-50 transition-all shadow-lg hover:shadow-xl flex items-center gap-2 group"
            >
              Get Free Quote
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </Link>
          </div>
        </motion.div>

        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link to="/" className="inline-flex items-center gap-2 mb-5">
              <Sparkles className="w-7 h-7 text-gold-400" />
              <div className="flex flex-col leading-none">
                <span className="font-display text-xl font-bold text-white">
                  Brite<span className="text-gold-400">Shine</span>
                </span>
                <span className="text-[9px] font-heading uppercase tracking-[0.3em] text-gold-400/60">
                  Cleaning Services
                </span>
              </div>
            </Link>
            <p className="text-white/50 text-sm leading-relaxed mb-6 max-w-xs">
              Premium cleaning services delivering spotless perfection to homes and businesses since 2015.
            </p>
            <div className="flex gap-3">
              {[Facebook, Instagram, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-gold-400 hover:border-gold-400/30 transition-all"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-heading font-semibold text-white text-sm mb-5 uppercase tracking-wider">
                {title}
              </h4>
              <ul className="space-y-3">
                {links.map(link => (
                  <li key={link.label}>
                    <Link
                      to={link.path}
                      className="text-white/40 text-sm hover:text-gold-400 transition-colors inline-flex items-center gap-1 group"
                    >
                      {link.label}
                      <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact Column */}
          <div>
            <h4 className="font-heading font-semibold text-white text-sm mb-5 uppercase tracking-wider">
              Contact
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-white/40 text-sm">
                <MapPin className="w-4 h-4 text-gold-500 shrink-0 mt-0.5" />
                <span>123 Shine Avenue, Business District, Harare</span>
              </li>
              <li className="flex items-center gap-3 text-white/40 text-sm">
                <Phone className="w-4 h-4 text-gold-500 shrink-0" />
                <a href="tel:+263771234567" className="hover:text-gold-400 transition-colors">+263 77 123 4567</a>
              </li>
              <li className="flex items-center gap-3 text-white/40 text-sm">
                <Mail className="w-4 h-4 text-gold-500 shrink-0" />
                <a href="mailto:info@briteshine.co.zw" className="hover:text-gold-400 transition-colors">info@briteshine.co.zw</a>
              </li>
              <li className="flex items-center gap-3 text-white/40 text-sm">
                <Clock className="w-4 h-4 text-gold-500 shrink-0" />
                <span>Mon – Sat: 7:00 AM – 6:00 PM</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-xs">
            © {new Date().getFullYear()} Brite Shine Cleaning Services. All rights reserved.
          </p>
          <div className="flex gap-6">
            <button onClick={onOpenPolicy} className="text-white/30 text-xs hover:text-gold-400 transition-colors cursor-pointer">
              Privacy Policy
            </button>
            <button onClick={onOpenCookies} className="text-white/30 text-xs hover:text-gold-400 transition-colors cursor-pointer">
              Cookie Policy
            </button>
          </div>
        </div>
      </div>
    </footer>
  )
}
