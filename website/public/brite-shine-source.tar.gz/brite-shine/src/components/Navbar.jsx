import { useState, useEffect, useCallback, useRef } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Search, Phone, ChevronRight, Sparkles } from 'lucide-react'

const NAV_LINKS = [
  { path: '/', label: 'Home' },
  { path: '/about', label: 'About' },
  { path: '/services', label: 'Services' },
  { path: '/gallery', label: 'Gallery' },
  { path: '/careers', label: 'Careers' },
  { path: '/contact', label: 'Contact' },
]

/* Searchable content index — maps keywords to routes + section IDs */
const SEARCH_INDEX = [
  { keywords: ['home', 'hero', 'welcome', 'brite shine', 'cleaning'], path: '/', section: null, label: 'Home' },
  { keywords: ['about', 'story', 'who we are', 'mission', 'values', 'team'], path: '/about', section: null, label: 'About Us' },
  { keywords: ['services', 'residential', 'commercial', 'deep clean', 'move in', 'move out', 'carpet', 'window', 'office', 'sanitization'], path: '/services', section: null, label: 'Our Services' },
  { keywords: ['pricing', 'plans', 'basic', 'standard', 'premium', 'price', 'cost', 'quote'], path: '/services', section: 'pricing', label: 'Pricing Plans' },
  { keywords: ['gallery', 'portfolio', 'before', 'after', 'photos', 'work', 'results'], path: '/gallery', section: null, label: 'Gallery' },
  { keywords: ['careers', 'jobs', 'hiring', 'work with us', 'apply', 'employment', 'openings'], path: '/careers', section: null, label: 'Careers' },
  { keywords: ['contact', 'call', 'email', 'phone', 'address', 'location', 'reach', 'message'], path: '/contact', section: null, label: 'Contact Us' },
  { keywords: ['testimonials', 'reviews', 'feedback', 'clients', 'customers'], path: '/', section: 'testimonials', label: 'Testimonials' },
  { keywords: ['faq', 'questions', 'help'], path: '/contact', section: 'faq', label: 'FAQ' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const location = useLocation()
  const navigate = useNavigate()
  const searchRef = useRef(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
    setSearchOpen(false)
  }, [location.pathname])

  useEffect(() => {
    if (searchOpen && searchRef.current) searchRef.current.focus()
  }, [searchOpen])

  /* Keyboard shortcut */
  useEffect(() => {
    const handler = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setSearchOpen(p => !p)
      }
      if (e.key === 'Escape') setSearchOpen(false)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  const handleSearch = useCallback((q) => {
    setSearchQuery(q)
    if (!q.trim()) { setSearchResults([]); return }
    const lower = q.toLowerCase()
    const results = SEARCH_INDEX.filter(item =>
      item.keywords.some(kw => kw.includes(lower)) || item.label.toLowerCase().includes(lower)
    )
    setSearchResults(results)
  }, [])

  const navigateToResult = (result) => {
    setSearchOpen(false)
    setSearchQuery('')
    navigate(result.path)
    if (result.section) {
      setTimeout(() => {
        const el = document.getElementById(result.section)
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }, 300)
    }
  }

  const isActive = (path) => location.pathname === path

  return (
    <>
      {/* Main Navbar */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'glass shadow-lg shadow-gold-900/5 py-3'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="relative">
                <Sparkles className="w-8 h-8 text-gold-500 group-hover:text-gold-400 transition-colors" />
                <div className="absolute inset-0 bg-gold-400/20 blur-lg rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-display text-xl font-bold tracking-tight text-charcoal">
                  Brite<span className="text-gold-500">Shine</span>
                </span>
                <span className="text-[10px] font-heading uppercase tracking-[0.25em] text-gold-600/70">
                  Cleaning Services
                </span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {NAV_LINKS.map(link => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`relative px-4 py-2 text-sm font-heading font-medium transition-colors rounded-full ${
                    isActive(link.path)
                      ? 'text-gold-700'
                      : 'text-charcoal/70 hover:text-charcoal'
                  }`}
                >
                  {link.label}
                  {isActive(link.path) && (
                    <motion.div
                      layoutId="nav-indicator"
                      className="absolute inset-0 bg-gold-100/60 rounded-full -z-10"
                      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                    />
                  )}
                </Link>
              ))}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-3">
              {/* Search Button */}
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2 rounded-full hover:bg-gold-100/50 transition-colors text-charcoal/60 hover:text-charcoal"
                aria-label="Search"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* CTA - Desktop */}
              <Link
                to="/contact"
                className="hidden lg:flex items-center gap-2 bg-charcoal text-white px-5 py-2.5 rounded-full text-sm font-heading font-medium hover:bg-gold-700 transition-all duration-300 shadow-lg shadow-charcoal/10 hover:shadow-gold-700/20"
              >
                <Phone className="w-4 h-4" />
                Get a Quote
              </Link>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="lg:hidden p-2 rounded-full hover:bg-gold-100/50 transition-colors"
                aria-label="Toggle menu"
              >
                {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-charcoal/30 backdrop-blur-sm z-40 lg:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed top-0 right-0 bottom-0 w-[85%] max-w-sm bg-cream z-50 lg:hidden shadow-2xl"
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-6 border-b border-gold-200/30">
                  <span className="font-display text-lg font-bold text-charcoal">
                    Brite<span className="text-gold-500">Shine</span>
                  </span>
                  <button onClick={() => setMobileOpen(false)} className="p-2">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <nav className="flex-1 px-4 py-6 space-y-1">
                  {NAV_LINKS.map((link, i) => (
                    <motion.div
                      key={link.path}
                      initial={{ opacity: 0, x: 30 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <Link
                        to={link.path}
                        className={`flex items-center justify-between px-4 py-3.5 rounded-xl text-base font-heading font-medium transition-all ${
                          isActive(link.path)
                            ? 'bg-gold-100/80 text-gold-800'
                            : 'text-charcoal/70 hover:bg-gold-50'
                        }`}
                      >
                        {link.label}
                        <ChevronRight className="w-4 h-4 opacity-40" />
                      </Link>
                    </motion.div>
                  ))}
                </nav>
                <div className="p-6 border-t border-gold-200/30">
                  <Link
                    to="/contact"
                    className="flex items-center justify-center gap-2 w-full bg-charcoal text-white py-3.5 rounded-xl font-heading font-medium hover:bg-gold-700 transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    Get a Free Quote
                  </Link>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Search Overlay */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-charcoal/40 backdrop-blur-md z-[60] flex items-start justify-center pt-[15vh]"
            onClick={() => setSearchOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -20 }}
              transition={{ duration: 0.2 }}
              className="w-full max-w-xl mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3 px-5 py-4 border-b border-gold-100">
                <Search className="w-5 h-5 text-gold-500 shrink-0" />
                <input
                  ref={searchRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  placeholder="Search pages, services, pricing…"
                  className="flex-1 bg-transparent outline-none text-charcoal placeholder:text-charcoal/30 font-body text-base"
                />
                <kbd className="hidden sm:inline-flex items-center gap-1 px-2 py-1 text-xs font-mono text-charcoal/40 bg-gold-50 rounded-md border border-gold-100">
                  ESC
                </kbd>
              </div>
              {searchResults.length > 0 && (
                <div className="p-2 max-h-64 overflow-y-auto">
                  {searchResults.map((r, i) => (
                    <button
                      key={i}
                      onClick={() => navigateToResult(r)}
                      className="w-full text-left px-4 py-3 rounded-xl hover:bg-gold-50 transition-colors flex items-center justify-between group"
                    >
                      <div>
                        <p className="text-sm font-heading font-medium text-charcoal">{r.label}</p>
                        <p className="text-xs text-charcoal/40">{r.path}{r.section ? `#${r.section}` : ''}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gold-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              )}
              {searchQuery && searchResults.length === 0 && (
                <div className="px-5 py-8 text-center text-charcoal/40 text-sm">
                  No results for "{searchQuery}"
                </div>
              )}
              {!searchQuery && (
                <div className="px-5 py-6 text-center text-charcoal/30 text-sm">
                  Start typing to search…
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
